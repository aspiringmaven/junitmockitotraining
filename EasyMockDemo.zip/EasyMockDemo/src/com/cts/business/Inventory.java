package com.cts.business;

import java.util.ArrayList;
import java.util.List;

import com.cts.entities.Product;
import com.cts.impls.IProductDao;

public class Inventory {
	private IProductDao proddao;
	private List<Product> productList;
	public Inventory()
	{
		productList=new ArrayList<Product>();
	}
	
	public void addProduct(Product product)
	{
		productList.add(product);
	}
	public void setProddao(IProductDao proddao) {
		this.proddao = proddao;
	}
	public double getTotalPrice()
	{
		int totalprice=0;
		 for(Product prod : productList)
		 {
			 totalprice+=proddao.getPrice(prod);
		 }
		return totalprice;
	}
	
	

}
