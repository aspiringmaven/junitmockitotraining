package com.cts.impls;

import com.cts.entities.Product;

public interface IProductDao {

	double getPrice(Product product);
}
