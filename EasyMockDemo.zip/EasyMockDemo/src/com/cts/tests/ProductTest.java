package com.cts.tests;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

import org.easymock.EasyMock;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.cts.business.Inventory;
import com.cts.entities.Product;
import com.cts.impls.IProductDao;
@RunWith(EasyMockRunner.class)
public class ProductTest {
	//step 1 create the mock
  @Mock
  IProductDao productdao;
  @TestSubject
  Inventory inv = new Inventory();
	@Test
	public void test() {
		Product p1=new Product();
		p1.setProductId(456);
		p1.setName("CD");
		p1.setAvailable(true);
		inv.addProduct(p1);
		Product p2=new Product();
		p1.setProductId(466);
		p1.setName("DVD");
		p1.setAvailable(false);
		inv.addProduct(p2);
		//step 2 set the expectation
		EasyMock.expect(productdao.getPrice(p1)).andReturn(50.0);
		EasyMock.expect(productdao.getPrice(p2)).andReturn(75.0);
		//step 3 replay
		EasyMock.replay(productdao);
		assertThat(inv.getTotalPrice(),is(125.0));
		
		
	}

}
