package com.cts.dao;

import com.cts.entities.Product;
import com.cts.impls.IProductDao;

public class ProductDao implements IProductDao{

	@Override
	public double getPrice(Product product) {
		// TODO Auto-generated method stub
		//database connection
		return 0;
	}

}
