package com.cts.tests;
import static org.mockito.Mockito.*;

import java.util.Iterator;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cts.business.TweeClient;
import com.cts.impls.ITweet;

public class TwitterTest {

	@Test
	public void test() {
		 TweeClient twitterClient = new TweeClient ();

	        ITweet iTweet = mock(ITweet.class);

	        when(iTweet.getMessage()).thenReturn("Using mockito is great");

	        //twitterClient.sendMessage(iTweet);
	     // use mock in test....
	        assertEquals(twitterClient .sendMessage(iTweet),"Using mockito is great");
	        
	        verify(iTweet, atLeastOnce()).getMessage();
	}
	// Demonstrates the return of multiple values
		@Test
		public void testMoreThanOneReturnValue() {
			Iterator i = mock(Iterator.class);
			when(i.next()).thenReturn("Mockito").thenReturn("is neat!!");
			String result = i.next() + " " + i.next();
			assertEquals("Mockito is neat!!", result);
		}

		/**
		 * Test return value dependent on method parameter.
		 */
		@Test
		public void testReturnValueDependentOnMethodParameter() {
			Comparable c = mock(Comparable.class);
			when(c.compareTo("Mockito")).thenReturn(1);
			when(c.compareTo("Eclipse")).thenReturn(2);
			// assert
			assertEquals(1, c.compareTo("Mockito"));
		}

		/**
		 * Test return value in dependent on method parameter.
		 */
		@Test
		public void testReturnValueInDependentOnMethodParameter() {
			Comparable c = mock(Comparable.class);
			when(c.compareTo(anyInt())).thenReturn(-1);
			assertEquals(-1, c.compareTo(9));
		}

		

}
