package com.cts.impls;

public interface ITweet {

	String getMessage();
}
