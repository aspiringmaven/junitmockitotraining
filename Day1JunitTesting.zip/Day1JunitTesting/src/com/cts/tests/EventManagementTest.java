package com.cts.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class EventManagementTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Called before all the tests");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Called after all the tests");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Called before every test");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Called after every test");
	}

	@Test
	public void Logintest() {
		//fail("Not yet implemented");
	}
	@Test
	public void Registertest() {
		//fail("Not yet implemented");
	}
}
