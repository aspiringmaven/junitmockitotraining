package com.cts.tests;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.cts.entities.Product;
@RunWith(value=Parameterized.class)
public class ProductParamTest {
private String expected;
private int id;
private String pname;
private Date pdop;

	
	public ProductParamTest(String expected, int id, String pname, Date pdop) {
	super();
	this.expected = expected;
	this.id = id;
	this.pname = pname;
	this.pdop = pdop;
}

	@Parameters(name = "{index}: get({1},{2},{3}) = {0}")
	public static Object[] getTestParameters() {
		return new Object[] {
				new Object[] {"Laptop",100, "Laptop",new Date(116,4,5)},
				new Object[] {"Mobile",200, "Mobile",new Date(113,3,5)},
				new Object[] {"Book",210, "Book",new Date(116,7,5)},
				new Object[] {"Bag",220, "Bag",new Date(116,7,7)},
				};
	}


	@Test
	public void test() {
		Product product = new Product();
		product.setProductId(id);
		product.setProductName(pname);
		product.setDop(pdop);
		assertThat(expected, is(product.getProductName()));
	}

}
