package com.cts.tests;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cts.dao.ProductDao;
import com.cts.entities.Product;

public class ProductTest {
	private static ProductDao productdao;
	private double delta=.1e-15;
	private Product prod;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		 productdao=new ProductDao();
		Product product=new Product();
		product.setProductId(4378);
		product.setProductName("Laptop");
		product.setDop(new Date(115,5,5));
		productdao.addProduct(product);
		 product=new Product();
			product.setProductId(4367);
			product.setProductName("Mobile");
			product.setDop(new Date(112,3,1));
			productdao.addProduct(product);
			 product=new Product();
				product.setProductId(4478);
				product.setProductName("Bag");
				product.setDop(new Date(116,5,1));
				productdao.addProduct(product);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
		productdao=null;
	}

	@Before
	public void setUp() throws Exception {
	 prod=new Product();
		
	}

	@After
	public void tearDown() throws Exception {
		prod=null;
		
	}

	@Test
	public void addProductTest() {
		//fail("Not yet implemented");
		prod.setProductId(35767);
		prod.setProductName("TV");
		prod.setDop(new Date(113,4,5));
		//prod=null;
		
		assertTrue(productdao.addProduct(prod));
		
	}
	
	@Test

	public void getProductByIdTest() {
				
		assertNotNull(productdao.getProductById(4367));
		
	}
	
	@Test

	public void getAllProductsTest() {
				
		//assertTrue(productdao.getAllProducts().size()>0);
		assertThat(productdao.getAllProducts(),hasSize(4));
		List<Integer> productIdList=new ArrayList<Integer>();
		for(Product p : productdao.getAllProducts())
			 productIdList.add(p.getProductId());
		  assertThat(productIdList, everyItem(greaterThan(500)));
		
		
	}
	@Test
//hamcrest library should on top of junitlib -change order of libraries
	public void checkDateTest() {
				
		//assertEquals("Rejected",productdao.checkExpiryDate(4367));
		//assertThat("Rejected",is(productdao.checkExpiryDate(4367)));
		assertThat("Rejected",equalTo(productdao.checkExpiryDate(4367)));
		
	}
	
	@Test
	//hamcrest library should on top of junitlib -change order of libraries
		public void checkFloatingDataTest() {
			double number1=678.6778;
			double number2=678.6778;
	     //assertEquals(number1, number2, delta);
			assertThat(number1,is(number2));
		}

	@Test
	//hamcrest library should on top of junitlib -change order of libraries
		public void anyOrderTest() {
		   
 			List<String> result = productdao.getNames();
			Collections.sort(result);
			assertThat(result,containsInAnyOrder("vb","java","j2ee","c#","python"));
			
		}
	
	@Test
	//hamcrest library should on top of junitlib -change order of libraries
		public void productPropertyTest() {
		   Product product=productdao.getProductById(4367);
		  assertThat(product, hasProperty("productId"));
		  assertThat(product, hasProperty("productName", equalTo("Mobile")));
		}
	@Test(expected=NullPointerException.class)		
		public void exceptionTest() {
		
		 List<Product> productList=null;
		 //assertThat(productList,hasSize(5));
		 int size = productList.size();
		}

}
