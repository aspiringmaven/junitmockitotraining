package com.cts.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import com.cts.entities.Product;

public class ProductDao {
	private List<Product> productList;
	private static Pattern pattern;
	private boolean status;

	public ProductDao() {
		super();
		this.productList = new ArrayList<Product>();
	}
	
	public boolean addProduct(Product product)
	{
		status=false;
		String namePattern="^[a-zA-z]*$";
		pattern = Pattern.compile(namePattern);
		if(product!=null)
		{
		  if(product.getProductId()>0)
		  {
			  if(pattern.matcher(product.getProductName()).find())
			  {
		this.productList.add(product);
		status=true;
			  }
		  }
		}
		return status;
	}
	
	public boolean editProduct(Product product)
	{
		for(Product prod : productList)
		{
			if(prod.getProductId()==product.getProductId())
			{
				prod.setProductName(product.getProductName());
				prod.setDop(product.getDop());
				status=true;
			}
		}
		return status;
	}

	public boolean deleteProduct(int productId)
	{
		for(Product prod : productList)
		{
			if(prod.getProductId()==productId)
			{
				productList.remove(prod);
				status=true;
			}
		}
		return status;
	}
	public Product getProductById(int productId)
	{
		Product response=null;
		for(Product prod : productList)
		{
			if(prod.getProductId()==productId)
			{
				response=prod;
			}
		}
		return response;
	}
	public List<Product> getAllProducts()
	{
		return productList;
	}
	
	public String checkExpiryDate(int productId)
	{
		String productState="Accepted"; 
		Calendar edop=Calendar.getInstance();
		for(Product prod : productList)
		{
			if(prod.getProductId()==productId)
			{
				edop.setTime(prod.getDop());
				edop.add(Calendar.MONTH, 6);
				
				if(edop.getTime().before(new Date()))
				{
					
					productState="Rejected";
				}
			}
		}
		return productState;
	}
	
	public List<String> getNames()
	{
		List<String> namelist = new ArrayList<String>();
		namelist.add("java");
		namelist.add("j2ee");
		namelist.add("c#");
		namelist.add("vb");
		namelist.add("python");
		return namelist;
	}
	
	
	
	
}
