package com.cts.impls;

import com.cts.entities.Email;

public interface ExternalEmailSystem {
public void send(String domain, String user, String body);
	
	public void send(Email email);
}
