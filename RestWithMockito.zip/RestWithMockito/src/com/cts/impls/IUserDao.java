package com.cts.impls;

import com.cts.entities.UserAccount;

public abstract class IUserDao {
 
	public abstract UserAccount getUserById(int id);
}
