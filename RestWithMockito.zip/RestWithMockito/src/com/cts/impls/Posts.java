package com.cts.impls;

import java.util.Date;

public final class Posts {
 
	 public String Message()
	 {
		 return "Received message at"+new Date().toLocaleString();
	 }
	
}
