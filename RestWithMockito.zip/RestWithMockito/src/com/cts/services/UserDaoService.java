package com.cts.services;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import com.cts.entities.UserAccount;
import com.cts.impls.IUserDao;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class UserDaoService extends IUserDao {


	public UserAccount getUserById(int id) {
		// TODO Auto-generated method stub
		ClientConfig clientConfig = new DefaultClientConfig();
		Client client=Client.create(clientConfig);
		WebResource service = client.resource
				(UriBuilder.fromUri("https://jsonplaceholder.typicode.com/").build());
	String cresponse = 
	  		service.path("users")
	  		.accept(MediaType.APPLICATION_JSON).get(String.class);
	System.out.println(cresponse);
	return null;
	
	}

}
