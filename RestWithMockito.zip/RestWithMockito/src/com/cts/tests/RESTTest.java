package com.cts.tests;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.cts.entities.UserAccount;
import com.cts.impls.IUserDao;
import com.cts.impls.Posts;
import com.cts.services.UserDaoService;

import vom.cts.business.UserInformation;
@RunWith(MockitoJUnitRunner.class)
public class RESTTest {
	private UserAccount useracct,spyacct;
	
	@Mock
	private IUserDao dao;
	
	  @InjectMocks
	private UserInformation userinfo=new UserInformation();
		@Before
		public void buildSpy() {
			useracct = new UserAccount();
			useracct.setId(36997);
			useracct.setName("Radha");
			useracct.setEmail("radha@cts.com");
			spyacct = spy(useracct);
		}
	  
	@Test
	public void test() {
		UserAccount useraccount =new UserAccount();
		useraccount.setEmail("test@cts.com");
			//when(dao.getUserById(1)).thenReturn(useraccount);	
		when(dao.getUserById(1)).thenAnswer(new Answer()
				{

					@Override
					public Object answer(InvocationOnMock invocation) throws Throwable {
						// TODO Auto-generated method stub
						return useraccount;
					}
			
				});
		
		assertThat(userinfo.getUserData(1),is(useraccount));
		 verify(dao, atLeastOnce()).getUserById(1);
	}
	

	
	@Test
	public void verifySpyEffectOnRealInstance() {
		useracct.setName("Bala");
		assertFalse(useracct.getName() ==spyacct.getName());
	}

}
