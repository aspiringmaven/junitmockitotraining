package com.cts.tests;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.*;

import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cts.entities.Email;
import com.cts.impls.ExternalEmailSystem;

import vom.cts.business.MailDeliverer;

import static org.junit.Assert.*;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

public class MailDelivererTest {

@InjectMocks private MailDeliverer subject = new MailDeliverer();
	
	@Mock private ExternalEmailSystem externalMailSystem;
	
	@Captor private ArgumentCaptor<Email> emailCaptor;
	
	@Before
	public void injectDoubles() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void sendsEmailByConstructingEmailObject() {
		String expectedUser = "tim";
		String expectedDomain = "wingfield.com";
		String expectedBody = "Hi Tim!";
		
		subject.deliver(expectedUser+"@"+expectedDomain,expectedBody);
		
		verify(externalMailSystem).send(emailCaptor.capture());
		Email email = emailCaptor.getValue();
		
		//assertThat(userinfo.getUserData(1),is(useraccount));
	}

	@Test
	public void sendsEmailBySplittingAddress() {
		String expectedBody = "Hi Tim!";
		
		subject.deliver("tim@wingfield.com",expectedBody);
		
		verify(externalMailSystem).send("wingfield.com","tim", expectedBody);
	}
	
}
