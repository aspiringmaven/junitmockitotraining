package vom.cts.business;

import com.cts.entities.UserAccount;
import com.cts.impls.IUserDao;
import com.cts.impls.Posts;

public class UserInformation {
 private IUserDao userdao;
 private Posts posts;

public void setUserdao(IUserDao userdao) {
	this.userdao = userdao;
}
 
public UserAccount getUserData(int id)
{
	return userdao.getUserById(id);
}

public String getPosts()
{
	return posts.Message();
}

public void setPosts(Posts posts) {
	this.posts = posts;
}
	
}
